import './App.css';
import { BrowserRouter as Router } from "react-router-dom";
import Main from './components/Main';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <Router>
        <Main />
      </Router>
    </div>
  );
}

export default App;
