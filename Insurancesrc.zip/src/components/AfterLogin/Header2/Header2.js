import React from 'react';
import Navbar2 from './Navbar2';

const Header2 = () => {
  return (
    <div>
      <div>  <Navbar2 />  </div>
    </div>
  )
}

export default Header2;