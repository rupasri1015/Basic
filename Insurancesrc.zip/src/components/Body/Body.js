import React from "react";
import Home from "./Home/Home";
import AboutUs from "./About/AboutUs";
import Login from "./Login/Login";
import EmailVerification from "./Login/EmailVerification";
import AfterLogin from "../AfterLogin/AfterLogin";
import VehicleDetails from "../Body/Vehicle/Vehicle";
import DForm from "./Driver/Driver";
import CoverageSelection from "./Coverage/CoverageSelection";
import MandatoryCoverage from "./Coverage/Mandatory";
import PhysicalDamage from "./Coverage/PhysicalDamage";
import LiabilityCoverage from "./Coverage/Liability";
import { DataProvider } from "./DataContext";
import { Routes, Route } from "react-router-dom";
import SideNav from "./Coverage/SideNav";
import Premium from "./Premium/Premium";
import ResendOtp from "./Login/ResendOtp";

function Body() {
  return (
    <DataProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/aboutUs" element={<AboutUs />} />
        <Route path="/login" element={<Login />} />
        <Route path="/EmailVerfication" element={<EmailVerification />} />
        <Route path="/resend" element={<ResendOtp />} />
        <Route path="/afterLogin" element={<AfterLogin />}>
          <Route index element={<VehicleDetails />} />
          <Route path="vehicleDetails" element={<VehicleDetails />} />
          <Route path="driver/:vehicleId" element={<DForm />} />
          <Route path="coverageSelection" element={<CoverageSelection />} />
          <Route path="coverages" element={<SideNav />} />
          <Route path="mandatory" element={<MandatoryCoverage />} />
          <Route path="liability" element={<LiabilityCoverage />} />
          <Route path="physicalDamage" element={<PhysicalDamage />} />
          <Route path="premium" element={<Premium />} />
        </Route>
      </Routes>
    </DataProvider>
  );
}

export default Body;
