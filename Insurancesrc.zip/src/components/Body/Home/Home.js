import React from "react";
import "./Home.css";
export default function Home() {
  return (
    // ****************whole body *************************
    <div className="home">
      <div className="left_div">
        <div className="overlay">
          <p>Get an auto insurance quote</p>
          <button>Get a quote</button>
        </div>
      </div>
    </div>
  );
}
