import { ErrorMessage, Field, Form, Formik } from "formik";
import React, { useState } from "react";
import * as yup from "yup";
import axios from "axios";
import "./Vehicle.css";
import Select from "react-select";
import SafetyFeatures from "./Safety";//created a new component
import { useNavigate } from "react-router-dom";
// for multiple selection in dropdown using checkboxes 

const VehicleDetails = () => {
  const [vehicleId, setVehicleId] = useState();
  const [make, setMake] = useState();
  const [model,setModel] = useState();
  const [year, setYear] = useState();
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  const [editClicked, setEditClicked] = useState(false);

  //-----------------declaring useNaviagte hook
  const navigate=useNavigate();

  ////--------------Drop down options-------------------//
  const options = [
    { value: "antiTheftDevices", label: "Anti-theft Devices" },
    { value: "antiLockBrakes", label: "Anti-lock Brakes (ABS)" },
    {
      value: "telematicsAndUsageBasedInsurance",
      label: "Telematics and Usage-Based Insurance",
    },
    { value: "airbags", label: "Airbags" },
  ];

  ////-----------Drop down styling-------------------//
  const customStyles = {
    control: (base) => ({
      ...base,
      height: 40,
      minHeight: 40,
      border: "1px solid black",
    }),
  };

  ////---------------Declaring field values--------------//
  const initialValues = {
    vehicleId: "",
    make: "",
    model: "",
    year: "",
    safetyFeatures: [],
  };

  ////------------------------Validations using yup liabriary-------------//
  const validationSchema = yup.object().shape({
    vehicleId: yup
      .string()
      .max(10, "Make cannot exceed 10 characters")
      .matches(
        /^[A-Z][A-Z0-9]*$/,
        "1st letter must be an alphabet,capitals and numbers only"
      )
      .required("Required"),
    make: yup
    .string()
    .max(10, "Make cannot exceed 10 characters")
    .matches(
      /^[A-Z][A-Z]*$/, 
      '1st letter must be an alphabet, only UPPERCCASE allowed')
    .required("Required"),
    model: yup
    .string()
    .max(10, "Model cannot exceed 10 characters")
    .matches(
      /^[A-Z][A-Z0-9]*$/, 
      '1st letter must be an alphabet,capitals and numbers only')
    .required("Required"),
    year: yup
      .string()
      .matches(/^\d+$/, "Only numbers are allowed")
      .test("is-valid-year", 
      "Year should be in 6 years range from current year ", function (value) {
        const currentYear = new Date().getFullYear();
        const selectedYear = parseInt(value, 10);

        return selectedYear >= currentYear - 6 && selectedYear <= currentYear;
      })
      .required("Required"),
  });

  ////-----------to get the data from database using vehicle id--------------//
  const fetchVehicleData = async (vehicleId, setFieldValue) => {
    try {
      const response = await axios.get(
        `http://localhost:8081/getById/${vehicleId}`
      );

      const data = response.data;
      if (data) {
        setFieldValue("vechileId", data.vehicleId);
        setFieldValue("make", data.make);
        setFieldValue("model", data.model);
        setFieldValue("year", data.year);
        setFieldValue("safetyFeatures", data.safetyFeatures);
        console.log(data.safetyFeatures);
      } else {
        alert("No data found for the given vehicle ID");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("Error fetching data. Please try again later.");
    }
  };

  ////----------get the data when click the edit button-------------//
  const handleEdit = (vehicleId, setFieldValue) => {
    if (!vehicleId) {
      setAttemptedSubmit(true);
      setFieldValue("vechileId", "");
      return;
    }

    setVehicleId(vehicleId);
    fetchVehicleData(vehicleId, setFieldValue);
    setEditClicked(true);
  };

  ////------------------update the data-----------------//
  const handleUpdate = (values) => {
    const safetyFeatures = values.safetyFeatures;
    axios
      .put(`http://localhost:8081/update/${vehicleId}`, {
        make: values.make,
        model: values.model,
        year: values.year,
        safetyFeatures,
      })
      .then((response) => {
        console.log(response);
        alert("Vehicle details updated successfully");
        window.location.reload();
      })
      .catch(() => {
        alert("updating vehicle details");
        window.location.reload();
      });
  };

  ////----------------------adding the details-------------//
  const handleSubmit = (values) => {
    console.log("form submitted with ",values);
    // navigate(`/afterLogin/driver/${vehicleId}`);
    const safetyFeatures = values.safetyFeatures;
    const make=values.make;
    const model=values.model;
    const year=values.year;
    axios
      .post("http://localhost:8081/addvechile", {
        vehicleId,
        make,
        model,
        year,
        safetyFeatures,
      })
      .then((response) => {
        console.log(vehicleId + "," + make + "," + model + "," + year);
        console.log("Selected Safety Features:", values.safetyFeatures);
        console.log(response);
        alert("Vehicle details added successfully");
        navigate(`/afterLogin/driver/${vehicleId}`);
        window.location.reload();
      })
      .catch(() => {
        alert("Invalid credentials");
        window.location.reload();
      });
  };

  return (
    <div className="login">
      <div className="vehicle-details-container">
        <div className="vehicle-details">Vehicle</div>
      <div className="vehicle-form-container">
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {(props) => {
            const {
              values,
              isSubmitting,
              handleChange,
              // handleBlur,
              handleSubmit,
              setFieldValue,
            } = props;
            return (
              
              <Form onSubmit={handleSubmit} className="vehicle-form">
              {/* <Form className="vehicle-form"> */}

                {/*----------------------- vechileId-------------------- */}
                <div className="vehicle-group">
                  <label htmlFor="vehicleId" className="vehicle-label">
                    Vehicle ID:
                  </label>
                  <Field
                    type="text"
                    id="vehicleId"
                    name="vehicleId"
                    value={values.vehicleId}
                    onChange={(e) => {
                      setVehicleId(e.target.value);
                      handleChange(e);
                    }}
                    className="vehicle-field"
                    // onChange={handleChange}
                    // onBlur = {handleBlur}
                  />
                  {attemptedSubmit && !values.vehicleId && (
                      <div className="errors">Required.</div>
                    )}
                  <ErrorMessage
                    name="vehicleId"
                    component="div"
                    className="errors"
                  />
                </div>

                {/*-------------make--------------------- */}
                <div className="vehicle-group">
                  <label htmlFor="make" className="vehicle-label">
                    Make:
                  </label>
                  <Field
                    type="text"
                    id="make"
                    name="make"
                    value={values.make}
                    onChange={(e) => {
                      setMake(e.target.value);
                      handleChange(e);
                    }}
                    className="vehicle-field"
                    // onBlur={handleBlur}
                  />
                  <br />
                  <ErrorMessage
                    name="make"
                    component="div"
                    className="errors"
                  />
                </div>

                {/* ----------------------model-------------------- */}
                <div className="vehicle-group">
                  <label htmlFor="model" className="vehicle-label">
                    Model:
                  </label>
                  <Field
                    type="text"
                    id="model"
                    name="model"
                    value={values.model}
                    onChange={(e) => {
                      setModel(e.target.value);
                      handleChange(e);
                    }}
                    className="vehicle-field"
                    // onChange={handleChange}
                    // onBlur={handleBlur}
                  />
                  <br />
                  <ErrorMessage
                    name="model"
                    component="div"
                    className="errors"
                  />
                </div>

                {/* --------------------------year------------------------- */}
                <div className="vehicle-group">
                  <label htmlFor="year" className="vehicle-label">
                    Year:
                  </label>
                  <Field
                    type="text"
                    id="year"
                    name="year"
                    value={values.year}
                    onChange={(e) => {
                      setYear(e.target.value);
                      handleChange(e);
                    }}
                    className="vehicle-field"
                    // onChange={handleChange}
                  />
                  <br />
                  <ErrorMessage
                    name="year"
                    component="div"
                    className="errors"
                  />
                </div>

                {/* ------------------safety Features---------------- */}
                <div className="vehicle-drop-down">
                  <label htmlFor="safetyFeatures" className="vehicle-label">
                    Safety Features:
                  </label>
                  <div className="vehicle-field-select">
                    <div className="select-wrapper">
                      <Select
                        isMulti
                        styles={customStyles}
                        components={{ Option: SafetyFeatures }}
                        options={options}
                        value={options.filter((option) =>
                          // values.safetyFeatures.includes(option.value)
                          values.safetyFeatures && values.safetyFeatures.includes(option.value)
                        )}
                        onChange={(selectedOptions) => {
                          setFieldValue(
                            "safetyFeatures",
                            selectedOptions
                              ? selectedOptions.map((option) => option.value)
                              : []
                          );
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* --------------------edit------------------- */}
                <button
                    type="button"
                    onClick={() => {
                      if (values.vehicleId) {
                        handleEdit(values.vehicleId, setFieldValue);
                      } else {
                        setAttemptedSubmit(true);
                      }
                    }}
                    className="vehicle-button"
                  >
                    Edit
                  </button>

                  {/* --------------------Update-------------------- */}
                  <button
                    type="submit"
                    onClick={() => handleUpdate(values)}
                    disabled={!editClicked}
                    className="vehicle-button"
                  >
                    Update
                  </button>

                  {/* ---------------------------submit------------------- */}
                <button
                  type="submit"
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="vehicle-button"
                >
                  SUBMIT
                </button>
              </Form>
            );
          }}
        </Formik>
      </div>
      </div>
    </div>
  );
};

export default VehicleDetails;
