
import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate} from "react-router -dom";
import { useParams } from 'react-router-dom';
// import "../Vehicle/Vehicle.css";
import "./Driver.css";
////------------------------Validations using yup liabriary-------------//
const validationSchema = Yup.object().shape({
    name: Yup.string()
    .matches(/^[a-zA-Z]+$/, 'Name must contain only letters')
    .min(2, 'Name must be at least 2 characters')
    .max(25, 'Name can be at most 50 characters')
    .required('Name is required'),
    age: Yup.number().required("Age is required"),
    numAccidents: Yup.number().required("Accidents is required"),
    // numOfViolations : Yup.number().required("Violations is required"),
    numAddDrivers: Yup.number().required('Please select the number of drivers'),
 
});

const DForm = () => {
  const { vehicleId } = useParams();
    const navigate = useNavigate();
  //---------------------Declaring field values
  const initialValues = {
    vehicleId : vehicleId,
    name: "",
    age: 19,
    gender: "",
    maritalStatus: "",
    numAccidents: 0,
    // numOfViolations: 0,
    numAddDrivers: 0,
    driverDetails: [], 
    };
    // , { setSubmitting }
    const handleSubmit = (values) => {
        // You can use Axios or any other method for this.
        console.log("Form submitted with values:", values);
        // navigate("/afterLogin/coverageSelection");
        axios
        .post("http://localhost:8082/api/driver/add", values)
        .then((response) => {
            console.log("Data sent successfully:", response.data);
            alert("Driver details saved successfully");
            navigate("/afterLogin/coverageSelection");
        })
        .catch((error) => {
            alert("invalid request");
            console.error("Error sending data:", error);
        });
        // setSubmitting(false);
    };

    const genderOptions = [
    { key: "Male", value: "male" },
    { key: "Female", value: "female" },
    ];

    const marriageOptions = [
        { key: "Married", value: "married" },
    { key: "UnMarried", value: "unmarried" },
    ];

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ values,touched, errors }) => (
        <Form className="driver-form">
            <div className='left-div'>
                    {/* *******************Vehicle Id */}
                    <div className='driver-input-div'>
                        <label 
                            htmlFor="vehicleId" 
                            className="label"
                        > 
                            Vehicle ID:
                        </label>
                        <Field
                            type="text"
                            id="vehicleId"
                            name="vehicleId"
                            value={vehicleId}
                            readOnly  
                            className = "input"
                        />
                        
                    </div>
                    {/* *********** Name *************************** */}
                    <div className="driver-input-div">
                    <label htmlFor="name" className="label">
                      Name:
                    </label>
                    <Field
                      type="text"
                      id="name"
                      name="name"
                    //   onBlur={handleBlur}
                      className="input"
                      placeholder="Enter your name"
                    />

                    {errors.name && touched.name && (
                      <ErrorMessage
                        name="name"
                        component="div"
                        className="errors"
                      />
                    )}
                    </div>

                    {/* ************* Age ************************* */}
                    <div className="driver-input-div">
                      <label htmlFor="age" className="label">
                        Age:
                      </label>
                      <Field as="select" id="age" name="age" className="input">
                        {Array.from({ length: 42 }, (_, i) => i + 19).map((age) => (
                          <option key={age} value={age}>
                            {age}
                          </option>
                        ))}
                      </Field>
                    </div>

                    {/* *********** Gender *************************** */}
                    <div className="driver-input-div">
                      <label className="label">Gender:</label>
                      <label className="command">
                        {genderOptions.map((option) => (
                          <label key={option.value}>
                            <Field
                              type="radio"
                              name="gender"
                              value={option.value}
                            //   onBlur={handleBlur}
                            />
                            {option.key}
                          </label>
                        ))}
                      </label>
                    </div>

                    {/* *********** Marital Status *************************** */}
                    <div className="driver-input-div">
                      <label className="label">Marital Status:</label>
                      <label className="command">
                        {marriageOptions.map((option) => (
                          <label key={option.value}>
                            <Field
                              type="radio"
                              name="maritalStatus"
                              value={option.value}
                            //   onBlur={handleBlur}
                            />
                            {option.key}
                          </label>
                        ))}
                      </label>
                    </div>   
         
                    {/* ************** Accidents *************** */}
                    <div className="driver-input-div">
                        <label htmlFor="numAccidents" className="label">
                          Accidents:
                        </label>
                        <Field
                          as="select"
                          id="numAccidents"
                          name="numAccidents"
                          className="input"
                        >
                          {Array.from({ length: 5 }, (_, i) => i).map((num) => (
                            <option key={num} value={num}>
                              {num}
                            </option>
                          ))}
                        </Field>
                        <ErrorMessage name="numAccidents" component="div" className='input-feedback'/>
                    </div>

                    {/* ************** Violations *************** */}
                    {/* <div className="driver-input-div">
                        <label htmlFor="numOfViolations" className="label">
                          Violations:
                        </label>
                        <Field
                          as="select"
                          id="numOfViolations"
                          name="numOfViolations"
                          className="input"
                        >
                          {Array.from({ length: 5 }, (_, i) => i).map((num) => (
                            <option key={num} value={num}>
                              {num}
                            </option>
                          ))}
                        </Field>
                        <ErrorMessage name="numOfViolations" component="div" className='input-feedback'/>
                    </div> */}

                    {/* **************** Additional drivers ***************** */}
                    <div className="driver-input-div">
                        <label htmlFor="numAddDrivers" className='label'>Additional Drivers:</label>
                        <Field
                            as="select"
                            id="numAddDrivers"
                            name="numAddDrivers"
                            className="input"
                        >
                            {Array.from({ length: 5 }, (_, index) => index).map((num) => (
                            <option key={num} value={num}>
                                {num}
                            </option>
                            ))}
                        </Field>
                        <ErrorMessage name='numAddDrivers' component="div" className='input-feedback'/>
                    </div>
                    {/* *********************  Button   ******************** */}
                    <button type="submit" className="driver-button">
                      SUBMIT
                    </button>
            </div>
            {/* --------------------------------------------------------- */}
            <div className='right-div'>
                {values.numAddDrivers > 0 && (
            <> {/* ----------------------------------- */}
              {Array.from({ length: values.numAddDrivers }).map((_, index) => (
                <div key={index} className="add-driver-form">
                <h3 className='add-driver-head'>Driver {index + 1}</h3>
                    {/* *********** Name *************************** */}
                    <div className="driver-input-div">
                    <label 
                    htmlFor={`driverDetails[${index}].addDriverName`}
                    className="label"
                    >
                    Name
                    </label>
                    <Field
                    type="text"
                    id={`driverDetails[${index}].addDriverName`}
                    name={`driverDetails[${index}].addDriverName`}
                    className="input"
                    placeholder="Enter driver name"
                    />
                    
                    <ErrorMessage
                        name={`driverDetails[${index}].addDriverName`}
                        component="div"
                        className="input-feedback"
                    />
                    
                    </div>
                    {/* ************* Age ************************* */}
                    <div className="driver-input-div">
                     <label htmlFor={`driverDetails[${index}].addDriverAge`} className='label'>Age</label>
                          <select
                              id={`driverDetails[${index}].addDriverAge`}
                              name={`driverDetails[${index}].addDriverAge`}
                              className="input"
                          >
                              {Array.from({ length: 42 }, (_, i) => i + 19).map((age) => (
                                  <option key={age} value={age}>
                                      {age}
                                  </option>
                              ))}
                          </select>
                    </div>
                    {/* *********** Gender *************************** */}
                    <div className="driver-input-div">
                        <label 
                            className="label"
                            htmlFor={`driverDetails[${index}].addDriverGender`}
                        >Gender:</label>
                        <label className="command">
                            {genderOptions.map((option) => (
                            <label key={option.value}>
                                <Field
                                type="radio"
                                id={`driverDetails[${index}].addDriverGender`}
                                name={`driverDetails[${index}].addDriverGender`}
                                value={option.value}
                                // onBlur={handleBlur}
                                />
                                {option.key}
                            </label>
                            ))}
                        </label>
                    </div>
                    {/* *********** MaritalStatus *************************** */}
                    <div className="driver-input-div">
                        <label 
                        htmlFor={`driverDetails[${index}].addDriverMaritalStatus`}
                        className="label">Marital Status:</label>
                        <label className="command">
                        {marriageOptions.map((option) => (
                            <label key={option.value}>
                            <Field
                                type="radio"
                                id={`driverDetails[${index}].addDriverMaritalStatus`}
                                name={`driverDetails[${index}].addDriverMaritalStatus`}
                                value={option.value}
                                // onBlur={handleBlur}
                            />
                            {option.key}
                            </label>
                        ))}
                        </label>
                    </div>           
                    {/* ************** Accidents *************** */}
                    <div className="driver-input-div">
                        <label
                            htmlFor={`driverDetails[${index}].addDriverAccidents`} 
                            className="label">
                            Accidents:
                        </label>
                        <Field
                            as="select"
                            id={`driverDetails[${index}].addDriverAccidents`}
                            name={`driverDetails[${index}].addDriverAccidents`}
                            className="input"
                        >
                            {Array.from({ length: 5 }, (_, i) => i).map((num) => (
                            <option key={num} value={num}>
                                {num}
                            </option>
                            ))}
                        </Field>
                        <ErrorMessage name="accidents" component="div" />
                    </div>
                </div>
              ))}
            </> //{/* ----------------------------------- */}
          )}
            </div>
            {/* ______________________________________________ */}
        </Form>
      )}
    </Formik>
  );
};

export default DForm;