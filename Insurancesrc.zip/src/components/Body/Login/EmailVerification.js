import React, { useState, useEffect } from "react";
import "./verify.css";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";

const EmailVerification = () => {

  const [otp, setOtp] = useState("");
  const [countdown, setCountdown] = useState({ minutes: 0, seconds: 30 });
  const [errors, setErrors] = useState({ otp: "" });
  const [showResendLink, setShowResendLink] = useState(false);
  const navigate = useNavigate();

  ////-------------------timer---------------------//
  useEffect(() => {
    let timer = setInterval(() => {
      setCountdown(prevCountdown => {
        if (prevCountdown.minutes === 0 && prevCountdown.seconds === 0) {
          clearInterval(timer);
          setShowResendLink(true); // Show the "RESEND OTP" button
          return prevCountdown;
        }
        if (prevCountdown.seconds === 0) {
          return { minutes: prevCountdown.minutes - 1, seconds: 59 };
        } else {
          return { minutes: prevCountdown.minutes, seconds: prevCountdown.seconds - 1 };
        }
      });
    }, 1000);

    return () => clearInterval(timer); // Clean up the timer when the component unmounts
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "otp") {
      setOtp(value);
      setErrors({ otp: validateOtp(value) });
    } else {
      setErrors("Incorrect Otp");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!otp) {
      setErrors({ otp: "OTP is required" });
      return; // Stop the submission process
    }
    axios
      .post("http://localhost:8080/api/agents/confirm", { otp })
      .then((response) => {
        console.log(response);
        console.log("otp" + otp);
        navigate("/afterLogin");
        alert("Login successful");
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Invalid Otp");
      });
  };

  const validateOtp = (otp) => {
    if (!otp) {
      return "OTP is required";
    } else if (otp.length !== 6) {
      return "OTP must be 6 characters";
    }
    return "";
  };

  return (
    <div className="verify-container">
      <h1>Verification Code</h1>
      <form onSubmit={handleSubmit} className="verify-form">
      <div className="flex-box">
          <i className="fa-solid fa-lock fa-beat"></i>
          <input
            type="text"
            id="otp"
            name="otp"
            value={otp}
            placeholder="OTP"
            onChange={handleChange}
            className="input"
          />
        </div>
      {errors.otp && <p className="error">{errors.otp}</p>}
        <div className="countdown">
          Time remaining: {`${countdown.minutes}:${countdown.seconds.toString().padStart(2, '0')}`}
        
        {showResendLink && (
            <NavLink to="/resend" className="resend-link">
            RESEND OTP
          </NavLink>
          )}
          </div>
        <div className="button-div">
          <button type="submit" className="button">
            SUBMIT
          </button>
        </div>
      </form>
    </div>
  );
};

export default EmailVerification;
