import React, { useState, useContext, useEffect } from "react";
import SideNav from "./SideNav";
import { useNavigate } from "react-router-dom";
import { DataContext } from "../DataContext";
import "./Coverages.css";

function MandatoryCoverage() {
  const { mandatoryData, setMandatoryData } = useContext(DataContext);

  const navigate = useNavigate();

  const [personalProtection, setPersonalProtection] = useState("");
  const [propertyDamage, setPropertyDamage] = useState("");

  useEffect(() => {
    if (mandatoryData) {
      setPersonalProtection(mandatoryData.personalProtection || "");
      setPropertyDamage(mandatoryData.propertyDamage || "");
    } else {
      setPersonalProtection("500");
      setPropertyDamage("500");
    }
  }, [mandatoryData]);

  const [errors, setErrors] = useState({
    personalProtection: "",
    propertyDamage: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "personalProtection") {
      setPersonalProtection(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        personalProtection: validateInput(value),
      }));
    } else if (name === "propertyDamage") {
      setPropertyDamage(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        propertyDamage: validateInput(value),
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const personalProtectionError = validateInput(personalProtection);
    const propertyDamageError = validateInput(propertyDamage);

    setErrors({
      personalProtection: personalProtectionError,
      propertyDamage: propertyDamageError,
    });

    if (personalProtectionError || propertyDamageError) {
      return;
    }

    const data = {
      personalProtection,
      propertyDamage,
    };

    console.log(data);
    setMandatoryData(data);
    navigate("/afterLogin/liability");
  };

  const validateInput = (value) => {
    if (!value) {
      return "Field is required";
    } else if (parseInt(value) < 500) {
      return "Value must be at least 500$";
    } else if (parseInt(value) > 10000) {
      return "Value can not exceed 10000$";
    }
    return "";
  };

  return (
    <div>
      <SideNav />
      <div>
        <h2>Mandatory Coverage</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group row">
            <label
              htmlFor="personalProtection"
              className="col-sm-5 col-form-label"
            >
              Personal Injury Protection (PIP) Coverage Limit:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="personalProtection"
                  name="personalProtection"
                  value={personalProtection}
                  onChange={handleChange}
                  className="form-control"
                />
              </div>
            </div>
            {errors.personalProtection && (
              <p className="errors">{errors.personalProtection}</p>
            )}
          </div>

          <div className="form-group row">
            <label htmlFor="propertyDamage" className="col-sm-5 col-form-label">
              Property Damage Liability (PDL) Coverage Limit:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="propertyDamage"
                  name="propertyDamage"
                  value={propertyDamage}
                  onChange={handleChange}
                  className="form-control"
                />
              </div>
            </div>
            {errors.propertyDamage && (
              <p className="errors">{errors.propertyDamage}</p>
            )}
          </div>
          <button type="submit" className="btn btn-primary mandatory-btn">
            Save & Next
          </button>
        </form>
      </div>
    </div>
  );
}

export default MandatoryCoverage;
