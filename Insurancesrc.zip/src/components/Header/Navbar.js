import React, { useState } from "react";
import logo from "../../images/kemper_Logo.png";
import Navbar2 from "../AfterLogin/Header2/Navbar2";
import {
  Container,
  Navbar,
  Nav,
} from "react-bootstrap";
import LinkStyles from "./LinkStyles";
import './Navbar.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars, faTimes  } from '@fortawesome/free-solid-svg-icons'
import { useAuth } from "../../AuthContext";

function NavBar() {
  const [collapsed, setCollapsed] = useState(true);
  const { isLoggedIn } = useAuth();

  const handleToggle = () => {
    setCollapsed(!collapsed);
  };
  // useEffect(() => {
  //     const userIsLoggedIn = checkIfUserIsLoggedIn();
  //     setIsLoggedIn(userIsLoggedIn);
  //   }, []);
  return (
    <>
      <Navbar style={{ backgroundColor: "#163f63", color: "white" }} expand="lg">
      <Container fluid>
        <Navbar.Brand>
          <img src={logo} className="navbar-logo" alt="logo" style={{height: "4vmin"}} />
        </Navbar.Brand>
        <Navbar.Toggle onClick={handleToggle} aria-controls="navbarScroll">
          <FontAwesomeIcon icon={collapsed ? faBars : faTimes} style={{ color: "white" }} />
        </Navbar.Toggle>
        <Navbar.Collapse id="navbarScroll">
          <Nav className="ms-auto" >
            <Nav.Link href="/" style={LinkStyles}>HOME</Nav.Link>
            <Nav.Link href="/aboutUs" style={LinkStyles} >ABOUT US</Nav.Link>
            <Nav.Link href="/login" style={LinkStyles} >LOG IN</Nav.Link>
            {/* <Nav.Link href="#" disabled>
              Link
            </Nav.Link> */}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    {isLoggedIn && <Navbar2 />}    
    </>
  );
}

export default NavBar;
