const LinkStyle = {
    fontSize: "18px",
    color: "white",
    fontWeight: "bold",
  };
  
  export default LinkStyle;