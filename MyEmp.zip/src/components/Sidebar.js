import React, { useState, useEffect } from "react";
import axios from "axios";
import { useAuth } from "../auths/Auth";
import { NavLink } from "react-router-dom";

import styled from "styled-components";
import { SidebarData } from "./SidebarData";
import SubMenu from "./SubMenu";

import { IconContext } from "react-icons/lib";
import logo from "../assets/pakricornlogo1.png";


const Nav = styled.div`
  position: fixed !important;
  top:0;
  margin-left: 18%; 
  padding-right: 5%; 
  width: 85%;
  background: #34495e;
  height: 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 2%;
  padding-bottom: 2%;
  padding-left: 10%
`;

// const NavIcon = styled(ink)`
//   margin-left: 2rem;
//   font-size: 2rem;
//   height: 80px;
//   display: flex;
//   justify-content: flex-start;
//   align-items: center;
// `;

const SidebarNav = styled.nav`
  background: #34495e;
  width: 250px;
  height: 100vh;
  display: flex;
  justify-content: center;

  position: fixed;
  top: 0;
  left: ${({ sidebar }) => (sidebar ? "0" : "0")};
  transition: 350ms;
  z-index: 10;
`;

const SidebarWrap = styled.div`
  width: 100%;
`;

const Sidebar = () => {
  const { signout, userId } = useAuth();
  console.log("userId : "+userId);
  const [sidebar] = useState("false");
  const [userName, setUserName] = useState("");

  // const showSidebar = () => setSidebar(!sidebar);

  //Fetch user details based on userId when component mounts
  useEffect(() => {
    axios.get(`http://localhost:8889/admin/login/fetch/${userId}`)
    .then((response) => {
      setUserName(response.data);
      })
      .catch ((error) => {
        console.error("Error fetching user details:", error);
      });
    }, [userId]);

    // const showSidebar = () => {
    //   setSidebar(!sidebar); // Define and toggle the sidebar state
    // };
    
  return (
    <div className="home-bg">
      <IconContext.Provider value={{ color: "#fff" }}>
        <Nav>
              {/* <NavIcon to="#">
                <FaIcons.FaBars onClick={showSidebar} />
              </NavIcon> */}
          <h1
            style={{
              fontSize: "1.2rem",
              color: "black",
              fontWeight : "bold",
              marginRight: "10%",
            }}
          >
            PAKRICORN TECHNO SOLUTIONS
          </h1>
          
          {
           userId ?  (
            <>
                <div>              
                {userName && <h3 style={{ fontSize: "1rem", color: "White",fontWeight : "bold", }}>Welcome, {userName.username}!</h3>}

                <h3 style={{fontSize: "0.9rem", color: "yellow",fontWeight : "bold", }} >
                  {new Date().toLocaleDateString()} &emsp; &emsp;
                  {new Date().toLocaleTimeString()}
                </h3>
                </div>
                <NavLink to="/" onClick={signout}>
                  SIGNOUT
                </NavLink>
            </>
              
            ) : (
              <></>
            ) 
            }                
           
        </Nav>
        
        <SidebarNav sidebar={sidebar}>
          <SidebarWrap>
            <div style={{}}>
              <img
                src={logo}
                className="logo"
                alt="logo"
                style={{
                  height: "38px",
                  width: "220px",
                  marginLeft: "15px",
                  marginRight: "10px",
                  marginTop: "",
                }}
              />
            </div>
            {/* <NavIcon to="#">
              <AiIcons.AiOutlineClose onClick={showSidebar} />
            </NavIcon> */}
            {SidebarData.map((item, index) => {
              return <SubMenu item={item} key={index} />;
            })}
          </SidebarWrap>
        </SidebarNav>
      </IconContext.Provider>
    </div>
  );
};

export default Sidebar;
