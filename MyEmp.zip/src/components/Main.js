import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';

const Main = () => (
  <div className='main-div'>
    <div className='left-div'> <Sidebar /> </div>
    <div className='right-div'> <Outlet />  </div>
  </div>
);

export default Main;
