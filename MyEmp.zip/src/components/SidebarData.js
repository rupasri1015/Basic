import React from "react";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import * as IoIcons from "react-icons/io";
import * as RiIcons from "react-icons/ri";

export const SidebarData = [
  {
    title:"Dashboard",
    path: "/login/home",
    icon: <AiIcons.AiFillHome />,
  },
  {
    
    title: "Employee Details",
    // path: "/Employees",
    icon: <AiIcons.AiOutlineTeam />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,

    subNav: [
      {
        title: "Add Employee Details",
        path: "/login/addEmployee",
        icon: <AiIcons.AiOutlineUserAdd/>,
      },
      {
        title: "Update Employee Details",
        path: "/login/updateEmployee",
        icon: <IoIcons.IoIosPaper />,
      },
      {
        title: "View Employee Details",
        path: "/login/viewEmployee",
        icon: <IoIcons.IoIosPaper />,
      },
      {
        title: "Archive Employee Details",
        path: "/login/deleteEmployee",
        icon: <IoIcons.IoIosPaper />,
      },
    ],
  },
  {
    title: "Employee Reports",
    // path: "/reports",
    icon: <IoIcons.IoIosPaper />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,

    subNav: [
      {
        title: "Calculate Employee Salaries",
        path: "/login/calculateEmployeeSalaries",
        icon: <IoIcons.IoIosPaper />,
        cName: "sub-nav",
      },
      {
        title: "Payroll for a Period",
        path: "/login/payrollForAPeriod",
        icon: <IoIcons.IoIosPaper />,
        cName: "sub-nav",
      },
    ],
  },

  {
    title: "Generate Letters",
    // path: "/events",
    icon: <FaIcons.FaEnvelopeOpenText />,

    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,

    subNav: [
      {
        title: "Letter1",
        path: "/login/events1",
        icon: <IoIcons.IoIosPaper />,
      },
      {
        title: "Letter2",
        path: "/login/events2",
        icon: <IoIcons.IoIosPaper />,
      },
    ],
  },
  {
    title: "Support",
    path: "/login/support",
    icon: <IoIcons.IoMdHelpCircle />,
  },
];
