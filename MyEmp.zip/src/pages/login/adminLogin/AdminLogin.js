import React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Formik } from "formik";
import * as Yup from "yup";
import { useAuth } from "../../../auths/Auth";

import payrollImage from "../../../assets/payroll_image.png";
import logo from "../../../assets/pakricornlogo.png";
import "./AdminLogin.css";

import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AdminLogin = () => {
  const { signin } =useAuth();
 const navigate = useNavigate();
 
 //Assigning initial values
  const initialValues = {
    userId: "",
    password: "",
  };

  const validationSchema = Yup.object().shape({
    userId: Yup.string().required("Email Required"),
    password: Yup.string()
      .min(6, "Password must be at least 6 characters")
      .max(10, "Password cannot exceed 10 characters")
      .required("Password is required")
  });
   // Handle validations
  const handleSubmit = (values) => {
   
    axios
      .post("http://localhost:8889/admin/login/login", values)
      .then((response) => {
            console.log(values.userID + "," + values.password);
            console.log(response);
            toast.success("Login Successful");
            navigate("/login/home", { replace : true });
        
      })
      .catch(() => {
            toast.error("Incorrect userId and Password not match");
      });
  };

 return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {(props) => {
        const {
          values,
          touched,
          errors,
          isSubmitting,
          handleChange,
          handleBlur,
          handleSubmit,
        } = props;

        return (
          <div>
            <ToastContainer position="top-center" autoClose={3000} />
            <section className="vh-100">
                <div className="container-fluid h-custom">
                <div className="row d-flex justify-content-center align-items-center h-100">
                        {/********* leftside image******** */}
                        <div className="col-md-9 col-lg-6 col-xl-5">
                            <img
                                src={payrollImage}
                                className="img-fluid"
                                alt="Sample_image"
                            />
                        </div>
                    {/* *************  ***************** */}
                    <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 ">
                        {/* -------------------------------- */}
                        <div className="text-center ">
                        <img
                            src={logo}
                            style={{ height: "50px", width: "350px" }}
                            alt="logo"
                            className="mb-2 pb-1"
                        />
                        <h4 
                            style={{color:"green", fontFamily:"cursive",fontSize:"1.4rem"}}
                            className="mt-1 mb-3 pb-1"
                        > Technology Pampered  </h4>
                        </div>
                        
                        {/* ************** Form ******************** */}
                        <form onSubmit={handleSubmit} className="border border-3 border-warning rounded p-4 mb-2">
                            <h2 className="text-center mb-3" style={{ color: "#ff8c1a" }}>
                                Login
                            </h2>
                            {/* ************ userID ********************** */}
                            <div className="form-outline mb-4">                 
                                <input
                                    id="userId"
                                    name="userId"
                                    type="text"
                                    placeholder="Enter User Id"
                                    value={values.userId}
                                    onChange={ handleChange}
                                        // (e) => {
                                    //   setEmail(e.target.value);
                                    //   handleChange(e);
                                    // }
                                // }
                                    onBlur={handleBlur}
                                    className="form-control"
                                />

                                {errors.userId && touched.userId && (
                                    <div className="text-danger">{errors.userId}</div>
                                )}
                            </div>
                            {/* ************* Password ****************** */}
                            <div className="form-outline mb-3">
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    placeholder="Enter password"
                                    value={values.password}
                                    onChange={handleChange}
                                    //     (e) => {
                                    //   setPassword(e.target.value);
                                    //   handleChange(e);
                                    // }
                                // }
                                    onBlur={handleBlur}
                                    className="form-control"
                                />
                                {errors.password && touched.password && (
                                    <div className="text-danger">{errors.password}</div>
                                )}
                            </div>
                            {/* ************* Remember me Forgot pwd *********************** */}
                            <div className="d-flex justify-content-between align-items-center">
                            {/* Check Box  */}
                            <div className="form-check mb-0">
                                <input
                                className="form-check-input me-2"
                                type="checkbox"
                                value=""
                                id="form2Example3"
                                />
                                <label className="form-check-label" htmlFor="form2Example3">
                                Remember me
                                </label>
                            </div>
                            <div>
                                <a href="#!" className="text-body">
                                Forgot password?
                                </a>
                            </div>
                            </div>
                            {/* ************* Button *********************** */}
                            <div className="d-flex flex-column align-items-center text-center text-lg-start mt-4 pt-2">
                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="btn btn-primary btn-lg"
                                    style={{
                                        paddingLeft: "2.5rem",
                                        paddingRight: "2.5rem",
                                    }}
                                    onClick ={
                                        () => {signin(values.userId);}
                                    }
                                >
                                    LOGIN
                                </button>
                                {/* --------------------------------------- */}
                                <p className="small fw-bold mt-2 pt-1 mb-0">
                                    Don't have an account?{" "}
                                    <a href="#!" className="link-danger">
                                    Register
                                    </a>
                                </p>
                                {/* ---------------------------------------- */}
                            </div>
                        </form>
                    </div>
                </div>
                </div>
            </section>
          </div>
        ); 
     }}    
    </Formik>
  );
};
export default AdminLogin;