import axios from "axios";
import React, { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const EmployeeList = () => {
  const [employeeData, setEmployeeData] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:8081/api/employees/list")
      .then((response) => {
        setEmployeeData(response.data);
      })
      .catch((error) => {
        console.error("Error fetching Employee Data", error);
      });
  }, []);

  const handleRowClick = (employeeId) => {
    // Programmatically navigate to the employee details page
    navigate(`/employee/${employeeId}`);
  };
  return (
    <div className="home-bg1">
      <h3>Employee List</h3>
      <div class="container">
        <table className="table table-hover">
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Email Id</th>
              <th>Department</th>
              <th>Joining CTC</th>
            </tr>
          </thead>
          <tbody>
            {employeeData.map((employee) => {
              return (
                // ? is used as optional chaining if employee id is null or
                // undefined then undefined is returned.

                <tr
                  key={employee.id}
                  onClick={() => handleRowClick(employee.id)}
                  style={{ cursor: "pointer" }}
                >
                  <td style={{ color: "#4a52ed" }}>
                    {employee?.firstName} - {employee?.id}
                  </td>
                  <td>{employee?.emailAddress}</td>
                  <td>{employee?.employeeDesignation}</td>
                  <td>{employee?.joiningCtc}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmployeeList;
