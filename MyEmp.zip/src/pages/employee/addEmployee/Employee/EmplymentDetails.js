import React from 'react';

const Employment = () => {
  return (
      <form
        autoComplete="off"
        className="addform-container"
        onSubmit={handleSubmit}
      >
        <div className="form-row">
          {/* --EMPLOYEE OFFER LETTER RELEASE DATE ----- */}
          <div className="form-input">
            <label htmlFor="employeeOfferLetterReleaseDate">
              Employee Offer Letter Release Date
              <span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="employeeOfferLetterReleaseDate"
              placeholder="MM/DD/YYYY"
              pattern="(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\d{4}"
              maxLength="10"
              value={values.employeeOfferLetterReleaseDate}
              onChange={(e) =>
                handleDateChange("employeeOfferLetterReleaseDate", e)
              }
              onBlur={handleBlur}
              max={new Date().toISOString().split("T")[0]}
              className={
                errors.employeeOfferLetterReleaseDate &&
                touched.employeeOfferLetterReleaseDate
                  ? "input-error"
                  : ""
              }
            />
            {errors.employeeOfferLetterReleaseDate &&
              touched.employeeOfferLetterReleaseDate && (
                <div className="input-feedback">
                  {errors.employeeOfferLetterReleaseDate}
                </div>
              )}
          </div>
          {/* ------employeeDesignation------------------ */}
          <div className="form-input">
            <label htmlFor="employeeDesignation">
              Employee Designation<span className="red-asterisk">*</span>
            </label>
            <select
              id="employeeDesignation"
              name="employeeDesignation"
              value={values.employeeDesignation}
              onChange={handleChange}
              onBlur={handleBlur}
              className={
                errors.employeeDesignation && touched.employeeDesignation
                  ? "input-error"
                  : ""
              }
            >
              <option value="">---select---</option>
              <option value="Junior Software Engineer">
                Junior Software Engineer
              </option>
              <option value="Software Engineer">Software Engineer</option>
              <option value="Senior Software Engineer">
                Senior Software Engineer
              </option>
              <option value="Associate Team Lead">
                Associate Team Lead
              </option>
              <option value="Team Lead">Team Lead</option>
              <option value="Associate Manager">Associate Manager</option>
              <option value="Manager">Manager</option>
              <option value="Associate Director">
                Associate Director
              </option>
              <option value="Director">Director</option>
            </select>
            {errors.employeeDesignation &&
              touched.employeeDesignation && (
                <div className="input-feedback">
                  {errors.employeeDesignation}
                </div>
              )}
          </div>
        </div>

        <div className="form-row">
          {/* -----------Joining Date------------------ */}
          <div className="form-input">
            <label htmlFor="joiningDate">
              Joining Date<span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="joiningDate"
              value={values.joiningDate}
              placeholder="MM/DD/YYYY"
              pattern="(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\d{4}"
              maxLength="10"
              onChange={(e) => handleDateChange("joiningDate", e)}
              onBlur={handleBlur}
              max={new Date().toISOString().split("T")[0]}
              className={
                errors.joiningDate && touched.joiningDate
                  ? "input-error"
                  : ""
              }
            />
            {errors.joiningDate && touched.joiningDate && (
              <div className="input-feedback">{errors.joiningDate}</div>
            )}
          </div>
          {/* -----------Joining CTC------------------ */}
          <div className="form-input">
            <label htmlFor="joiningCtc">
              Joining CTC<span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="joiningCtc"
              value={values.joiningCtc}
              onChange={handleChange}
              onBlur={handleBlur}
              className={
                errors.joiningCtc && touched.joiningCtc
                  ? "input-error"
                  : ""
              }
            />
            {errors.joiningCtc && touched.joiningCtc && (
              <div className="input-feedback">{errors.joiningCtc}</div>
            )}
          </div>
        </div>

        <div className="form-row">
          {/* -----------Hike Letter Date ------------------ */}
          <div className="form-input">
            <label htmlFor="hikeLetterDate">Hike Letter Date</label>
            <input
              type="text"
              name="hikeLetterDate"
              placeholder="MM/DD/YYYY"
              pattern="(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\d{4}"
              maxLength="10"
              value={values.hikeLetterDate}
              onChange={(e) => handleDateChange("hikeLetterDate", e)}
              onBlur={handleBlur}
              className={
                errors.hikeLetterDate && touched.hikeLetterDate
                  ? "input-error"
                  : ""
              }
              max={new Date().toISOString().split("T")[0]}
            />
            {errors.hikeLetterDate && touched.hikeLetterDate && (
              <div className="input-feedback">
                {errors.hikeLetterDate}
              </div>
            )}
          </div>
          {/* --------- Hike CTC -------------- */}
          <div className="form-input">
            <label htmlFor="hikeCtc">Hike CTC </label>
            <input
              type="text"
              name="hikeCtc"
              value={values.hikeCtc}
              onChange={handleChange}
              onBlur={handleBlur}
              maxLength="50"
              className={
                errors.hikeCtc && touched.hikeCtc ? "input-error" : ""
              }
            />
            {errors.hikeCtc && touched.hikeCtc && (
              <div className="input-feedback">{errors.hikeCtc}</div>
            )}
          </div>
        </div>

        <div className="form-row">
          {/* --------- Hike Designation -------------- */}
          <div className="form-input">
            <label htmlFor="hikeDesignation">Hike Designation</label>
            <input
              type="text"
              name="hikeDesignation"
              value={values.hikeDesignation}
              onChange={handleChange}
              onBlur={handleBlur}
              maxLength="50"
              className={
                errors.hikeDesignation && touched.hikeDesignation
                  ? "input-error"
                  : ""
              }
            />
            {errors.hikeDesignation && touched.hikeDesignation && (
              <div className="input-feedback">
                {errors.hikeDesignation}
              </div>
            )}
          </div>
          {/* ------------ Hike Letter Effective Date ------------------ */}
          <div className="form-input">
            <label htmlFor="hikeLetterEffectiveDate">
              Hike Letter Effective Date
            </label>
            <input
              type="text"
              name="hikeLetterEffectiveDate"
              placeholder="MM/DD/YYYY"
              pattern="(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\d{4}"
              maxLength="10"
              value={values.hikeLetterEffectiveDate}
              onChange={(e) =>
                handleDateChange("hikeLetterEffectiveDate", e)
              }
              onBlur={handleBlur}
              className={
                errors.hikeLetterEffectiveDate &&
                touched.hikeLetterEffectiveDate
                  ? "input-error"
                  : ""
              }
              max={new Date().toISOString().split("T")[0]}
            />
            {errors.hikeLetterEffectiveDate &&
              touched.hikeLetterEffectiveDate && (
                <div className="input-feedback">
                  {errors.hikeLetterEffectiveDate}
                </div>
              )}
          </div>
        </div>

        <div className="form-row">
          {/* ------- Employee Status ---------- */}
          <div className="form-input">                  
            <label htmlFor="employeeStatus">Employee Status</label>
            <select
              name="employeeStatus"
              value={values.employeeStatus}
              onChange={handleChange}
              onBlur={handleBlur}
              className={
                errors.employeeStatus && touched.employeeStatus
                  ? "input-error"
                  : ""
              }
            >
              <option value="">---Select---</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            {errors.employeeStatus && touched.employeeStatus && (
              <div className="input-feedback">
                {errors.employeeStatus}
              </div>
            )}
          </div>
          {/* ------  Relieving Date --------- */}
          <div className="form-input">
            <label htmlFor="relievingDate">Relieving Date</label>
            <input
              type="text"
              name="relievingDate"
              placeholder="MM/DD/YYYY"
              maxLength="10"
              value={values.relievingDate}
              onChange={(e) => handleDateChange("relievingDate", e)}
              onBlur={handleBlur}
              className={
                errors.relievingDate && touched.relievingDate
                  ? "input-error"
                  : ""
              }
            />

            {errors.relievingDate && touched.relievingDate && (
              <div className="input-feedback">{errors.relievingDate}</div>
            )}
          </div>
        </div>

        <div className="form-row">
          {/* --------- Project Name -------------- */}
          <div className="form-input">
            <label htmlFor="employmentStartDate">
              Project Name <span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="projectName"
              value={values.projectName}
              onChange={handleChange}
              onBlur={handleBlur}
              className={
                errors.projectName && touched.projectName
                  ? "input-error"
                  : ""
              }
            />
            {errors.projectName && touched.projectName && (
              <div className="input-feedback">{errors.projectName}</div>
            )}
          </div>
          {/* --------------CYCLE WORKING IN ------------------- */}
          <div className="form-input">
            <label htmlFor="cycleWorkingIn">
              Cycle Working In
              <span className="red-asterisk">*</span>
            </label>
            <select
              id="cycleWorkingIn"
              name="cycleWorkingIn"
              value={values.cycleWorkingIn}
              onChange={handleChange}
              onBlur={handleBlur}
              className={
                errors.cycleWorkingIn && touched.cycleWorkingIn
                  ? "input-error"
                  : ""
              }
            >
              <option value="">---select---</option>
              <option value="cycle1"> cycle 1 </option>
              <option value="cycle2"> cycle 2 </option>
              <option value="cycle3"> cycle 3 </option>
              <option value="cycle4"> cycle 4 </option>
            </select>
            {errors.cycleWorkingIn && touched.cycleWorkingIn && (
              <div className="input-feedback">
                {errors.cycleWorkingIn}
              </div>
            )}
          </div>
        </div>

        <button
        className="submit-add"
        type="submit"
        disabled={isSubmitting}
      >
        Submit
      </button>
      </form>
  )
}

export default Employment;
