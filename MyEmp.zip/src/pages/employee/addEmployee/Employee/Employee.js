import React from "react";
import { Formik } from "formik";
import axios from "axios";
import "./AddEmployeeDetails.css";
// import Datepicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";

import { 
  initialValue, 
  EmployeeSchema,
  formatDateString,
  handleDateChange, } from "./EmploySchema";

const Employee = () => {
  const handleSubmit = async (values, { resetForm }) => {
    await axios.post("http://localhost:8081/api/employees/add", values);
    alert("Data Submitted Successfully");
    console.log(values);

    resetForm();
  };
  
  return (
    <div className="container-add">
      <Formik
        initialValues={initialValue}
        validationSchema={EmployeeSchema}
        onSubmit={handleSubmit}
      >
        {(props) => {
          const {
            values,
            isSubmitting,
            errors,
            touched,
            handleBlur,
            handleChange,
            setFieldValue,
            handleSubmit,
          } = props;

          const handleDateChange = (fieldName, e) => {
            setFieldValue(fieldName, formatDateString(e.target.value));
          };

          return (
            <form
              autoComplete="off"
              className="addform-container"
              onSubmit={handleSubmit}
            >
              <h2>Add New Employee</h2>
              <div className="form-column">
                
              </div>

              <div className="form-column">
                
              </div>

              <div className="form-column">
                
              </div>
            

             
              <button
                className="submit-add"
                type="submit"
                disabled={isSubmitting}
              >
                Submit
              </button>
            </form>
          );
        }}
      </Formik>
    </div>
  );
};

export default Employee;
