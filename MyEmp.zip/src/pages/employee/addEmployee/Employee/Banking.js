import React from 'react';

const Salary = () => {
  return (
    <form
      autoComplete="off"
      className="addform-container"
      onSubmit={handleSubmit}
    >
      <h2>Banking</h2>

      <div className="form-row">                
        {/* --------- Tax Identification Number -------------- */}
        <div className="form-input">
          <label htmlFor="taxIdentificationNumber">
            Tax Identification Number
            <span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="taxIdentificationNumber"
            value={values.taxIdentificationNumber}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.taxIdentificationNumber &&
              touched.taxIdentificationNumber
                ? "input-error"
                : ""
            }
          />
          {errors.taxIdentificationNumber &&
            touched.taxIdentificationNumber && (
              <div className="input-feedback">
                {errors.taxIdentificationNumber}
              </div>
            )}
        </div>
      </div>
      
      <div className="form-row">
        {/* -----ACCOUNT NUMBER------------ */}
        <div className="form-input">
          <label htmlFor="accountNumber">
            Account Number<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="accountNumber"
            value={values.accountNumber}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.accountNumber && touched.accountNumber
                ? "input-error"
                : ""
            }
          />
          {errors.accountNumber && touched.accountNumber && (
            <div className="input-feedback">{errors.accountNumber}</div>
          )}
        </div>
        {/* -----ROUTING NUMBER------------ */}
        <div className="form-input">
          <label htmlFor="routingNumber">
            Routing Number<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="routingNumber"
            value={values.routingNumber}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.routingNumber && touched.routingNumber
                ? "input-error"
                : ""
            }
          />
          {errors.routingNumber && touched.routingNumber && (
            <div className="input-feedback">{errors.routingNumber}</div>
          )}
        </div>
      </div>  
      
      <div className="form-row">
        {/* -------BANK NAME ---------------- */}
        <div className="form-input">
          <label htmlFor="bankName">
            Bank Name<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="bankName"
            value={values.bankName}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.bankName && touched.bankName ? "input-error" : ""
            }
          />
          {errors.bankName && touched.bankName && (
            <div className="input-feedback">{errors.bankName}</div>
          )}
        </div>
        {/* -----BANK BRANCH ------------ */}
        <div className="form-input">
          <label htmlFor="bankBranch">
            Bank Branch<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="bankBranch"
            value={values.bankBranch}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.bankBranch && touched.bankBranch
                ? "input-error"
                : ""
            }
          />
          {errors.bankBranch && touched.bankBranch && (
            <div className="input-feedback">{errors.bankBranch}</div>
          )}
        </div>
      </div>                         
      
      <button 
        className="submit-add"
        type="submit"
        disabled={isSubmitting}
      >
        Submit
      </button>
    </form>
         
  )
}

export default Salary
