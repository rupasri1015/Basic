import React from 'react';

const Personal = () => {
  return (
    <form
      autoComplete="off"
      className="addform-container"
      onSubmit={handleSubmit}
    >
      <h2>Personal Information</h2>
      <div className="form-row">
        {/* ----------- FIRST NAME ----------------- */}
        <div className="form-input">
          <label htmlFor="firstName">
            First Name<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="firstName"
            value={values.firstName}
            onChange={handleChange}
            onBlur={handleBlur}
            autoFocus
            className={
              errors.firstName && touched.firstName ? "input-error" : ""
            }
          />
          {errors.firstName && touched.firstName && (
            <div className="input-feedback">{errors.firstName}</div>
          )}
        </div>
        {/* ------------LAST NAME ----------------------- */}
        <div className="form-input">
          <label htmlFor="lastName">
            Last Name<span className="red-asterisk">*</span>
          </label>
          <input
            type="text"
            name="lastName"
            value={values.lastName}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.lastName && touched.lastName ? "input-error" : ""
            }
          />
          {errors.lastName && touched.lastName && (
            <div className="input-feedback">{errors.lastName}</div>
          )}
        </div>
      </div>

      <div className="form-row">
        {/* --------- ADDRESS ---------- */}
        <div className="form-input">
          <label htmlFor="address">
            Address<span className="red-asterisk">*</span>
          </label>
          <textarea
            type="text"
            name="address"
            value={values.address}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.address && touched.address ? "input-error" : ""
            }
          />
          {errors.address && touched.address && (
            <div className="input-feedback">{errors.address}</div>
          )}
        </div>
        {/* ----------CONTACT NUMBER ---------------- */}
        <div className="form-input">
          <label htmlFor="contactNumber">
            Contact Number<span className="red-asterisk">*</span>
          </label>
          <input
            type="tel"
            name="contactNumber"
            value={values.contactNumber}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.contactNumber && touched.contactNumber
                ? "input-error"
                : ""
            }
          />
          {errors.contactNumber && touched.contactNumber && (
            <div className="input-feedback">{errors.contactNumber}</div>
          )}
        </div>
      </div>

      <div className="form-row">
        {/* -------- EMAIL ADDRESS ------------------ */}
        <div className="form-input">
          <label htmlFor="emailAddress">
            Email Address<span className="red-asterisk">*</span>
          </label>
          <input
            type="email"
            name="emailAddress"
            value={values.emailAddress}
            onChange={handleChange}
            onBlur={handleBlur}
            className={
              errors.emailAddress && touched.emailAddress
                ? "input-error"
                : ""
            }
          />
          {errors.emailAddress && touched.emailAddress && (
            <div className="input-feedback">{errors.emailAddress}</div>
          )}
        </div>
        {/* --------- DATE OF BIRTH -------------- */}
        <div className="form-input">
          <label htmlFor="dateOfBirth">
            Date Of Birth<span className="red-asterisk">*</span>
          </label>

          <input
            type="text"
            name="dateOfBirth"
            placeholder="MM/DD/YYYY"
            pattern="(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\d{4}"
            maxLength="10"
            value={values.dateOfBirth}
            onChange={(e) => handleDateChange("dateOfBirth", e)}
            onBlur={handleBlur}
            max={new Date().toISOString().split("T")[0]}
            className={
              errors.dateOfBirth && touched.dateOfBirth
                ? "input-error"
                : ""
            }
          />
          {errors.dateOfBirth && touched.dateOfBirth && (
            <div className="input-feedback">{errors.dateOfBirth}</div>
          )}
        </div>
      </div>

      
      <button
        className="submit-add"
        type="submit"
        disabled={isSubmitting}
      >
        Submit
      </button>
    </form>
  );
}

export default Personal;
