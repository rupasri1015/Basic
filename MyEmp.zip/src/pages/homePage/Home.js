import React,{useState,useEffect} from "react";
import "./Home.css";
import axios from "axios";
import {Link} from "react-router-dom";


const Home = () => {
  const[data,setData] = useState([]);

  useEffect(()=>{
    axios.get("http://localhost:8081/api/employees/list")
    .then((response)=>{
      setData(response.data);
    })
    .catch((error) => {
      console.error("Error fetching employee data:", error);
    });

  },[])
  return (
    <div className="home-bg1">
      <h3>Dash Board</h3>
      <div className="dashboard-row">
        <div className="dashboard-box">
          <p>Total Number Of Employees </p>
          <h1 style={{color:"blue"}}>
            <Link to="/login/employeeList">{data.length}</Link></h1>
        </div>

        <div className="dashboard-box">
          <p>Active Employees </p>
          <h1 style={{color:"green"}}>4</h1>
        </div>

        <div className="dashboard-box">
          <p>Inactive Employees </p>
          <h1 style={{color:"red"}}>4</h1>
        </div>
      </div>
    </div>
  );
};

export default Home;
