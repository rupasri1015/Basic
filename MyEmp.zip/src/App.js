import { AuthProvider } from "./auths/Auth";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import AdminLogin from "./pages/login/adminLogin/AdminLogin";
import Main from "./components/Main";
import Home from "./pages/homePage/Home";

import AddEmployeeDetails from "./pages/employee/addEmployee/AddEmployeeDetails";
import UpdateEmployeeDetails from "./pages/employee/updateEmployee/UpdatingEmployeeDetails";
import ViewEmployeeDetails from "./pages/employee/viewEmployee/ViewEmployeeDetails";
import DeleteEmployeeDetails from "./pages/employee/deleteEmployee/DeleteEmployeeDetails";
import EmployeeList from "./pages/employee/employeeList/EmployeeList";

import CalculateEmployeeSalaries from "./pages/reports/calculateEmployeeSalaries/CalculateEmployeeSalaries";
import PayrollForAPeriod from "./pages/reports/payrollForAPeriod/PayrollForAPeriod";

import Support from "./pages/support/Support";

function App() {
  return (
    <AuthProvider>
      <Router>        
        <Routes>
          <Route path="/" element={<AdminLogin />} />

          <Route path="/login" element={<Main />}>
            <Route index element={<Home />} />
            <Route path="home" element={<Home />} />

            <Route path="employeeList" element={<EmployeeList />} />
            <Route path="addEmployee"    element={<AddEmployeeDetails />} />
            <Route path="updateEmployee" element={<UpdateEmployeeDetails />} />
            <Route path="viewEmployee"   element={<ViewEmployeeDetails />} />
            <Route path="deleteEmployee" element={<DeleteEmployeeDetails />} />
           
            <Route path="calculateEmployeeSalaries" element={<CalculateEmployeeSalaries />} />
            <Route path="payrollForAPeriod" element={<PayrollForAPeriod />} />

            <Route path="support" element={<Support />} />
          </Route>
          
        </Routes>
      </Router>
     </AuthProvider>
  );
}

export default App;
