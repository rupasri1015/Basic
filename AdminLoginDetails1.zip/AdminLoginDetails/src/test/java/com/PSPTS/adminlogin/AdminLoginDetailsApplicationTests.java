package com.PSPTS.adminlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminLoginDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
