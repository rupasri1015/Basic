package com.PSPTS.adminlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminLoginDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminLoginDetailsApplication.class, args);
	}

}
