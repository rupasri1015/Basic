package com.PSPTS.adminlogin.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginadminResponse {

	String message;
	Boolean status;
	
}
