// App.js
import React from 'react';
import "./App.css";
import MoviesSearch from './MoviesSearch';

function Task() {
  return (
    <div className="App">
      <MoviesSearch />
    </div>
  );
}

export default Task;

