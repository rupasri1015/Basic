import React, {useState} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function ResendOtp() {
  const [email, setEmail] = useState("");
  const [resendError, setResendError] = useState("");
  const navigate=useNavigate();

  const handleEmailChange = (e) => {
    const { value } = e.target;
    setEmail(value);
  };

  const handleResendOtp = () => {
    if (!email) {
      setResendError("Email is required");
      return;
    }
    axios
      .post("http://localhost:8080/api/agents/resendotp", { email })
      .then((response) => {
        console.log(response);
        alert("OTP has been resent");
        navigate("/EmailVerfication");
      })
      .catch((error) => {
        console.log("Error:", error);
        alert("Error resending OTP");
      });
  };
  return (
    <div className="verify-container">
        <h1>Verification Code</h1>
      <form className="verify-form">
        <div className="flex-box">
          <i className="fa-solid fa-envelope fa-beat"></i>
          <input
            type="email"
            id="email"
            name="email"
            value={email}
            placeholder="Email"
            onChange={handleEmailChange}
            className="input"
          />
        </div>
        {resendError && <p className="error">{resendError}</p>}
        <button type="button" onClick={handleResendOtp} className="button">
          SUBMIT
        </button>
      </form>
    </div>
  );
}

export default ResendOtp;
