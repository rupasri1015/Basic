import React, { useState, useEffect } from "react";
import "./Login.css";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import logo from "../../../images/legend.png";

const Login = () => {

  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [agentid, setAgentId] = useState("");
  const [agentIdSuggestions, setAgentIdSuggestions] = useState([]);

  const initialValues = {
    email: "",
    password: "",
    agentid: "",
  };

  const validationSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email").required("Email Required"),
    password: Yup.string()
      .min(8, "Password must be at least 8 characters")
      .max(30, "Password cannot exceed 30 characters")
      .required("Password is required"),
    agentid: Yup.string()
      .matches(/^kai\d{3}$/, "Invalid Agent ID")
      .required("Agent ID is required"),
  });

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/agents/ids")
      .then((response) => {
        const agentIds = response.data;
        console.log("Agent IDs:", agentIds);
        setAgentIdSuggestions(agentIds);
      })
      .catch((error) => {
        console.error("Error fetching agent IDs:", error);
      });
  }, []);

  const handleSubmit = (e) => {
    // Handle validations
    axios
      .post("http://localhost:8080/api/agents/login", {
        email,
        password,
        agentid,
      })
      .then((response) => {
        console.log(email + "," + password + "," + agentid);
        console.log(response);
        alert("Please check the email for account verification");
        // alert(email);
        window.location.reload();
      })
      .catch(() => {
        alert("Invalid credentials");
        window.location.reload();
      });
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {(props) => {
        const {
          values,
          touched,
          errors,
          isSubmitting,
          handleChange,
          handleBlur,
          handleSubmit,
        } = props;

        return (
          <div className="login">
            <h1 className="h1 pt-1">Agent Login</h1>
            <fieldset className="login-fieldset">
              <legend className="login-legend text-center">
                <img src={logo} className="legend-img" alt="Logo" />
              </legend>
              {/* ************************************* */}
              <form onSubmit={handleSubmit} className="form">
                {/* ************ Email ********************** */}
                <div className="inputs">
                  <div className="flex-box">
                    <div className="leading-icon">
                      <i className="fa-solid fa-envelope fa-beat"></i>
                    </div>
                    <label htmlFor="email" className="label">
                      Email
                    </label>
                  </div>
                  {/* ------------------------------------------------ */}

                  {/* <div className="flex-box"> */}
                  <input
                    id="email"
                    name="email"
                    type="text"
                    placeholder="Enter your email"
                    value={values.email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      handleChange(e);
                    }}
                    onBlur={handleBlur}
                    className="input"
                  />

                  {errors.email && touched.email && (
                    <div className="input-feedback">{errors.email}</div>
                  )}
                </div>

                {/* ************* Password ****************** */}
                <div className="inputs">
                  <div className="flex-box">
                    <div className="leading-icon">
                      <i className="fa-solid fa-lock fa-beat"></i>
                    </div>
                    <label htmlFor="password" className="label">
                      Password
                    </label>
                  </div>
                  {/* -------------------------------------------------- */}
                  {/* <div className="flex-box"> */}
                  <input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Enter your password"
                    value={values.password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      handleChange(e);
                    }}
                    onBlur={handleBlur}
                    className="input"
                  />
                  {errors.password && touched.password && (
                    <div className="input-feedback">{errors.password}</div>
                  )}
                </div>
                {/* **************** dropdown ****************************/}
                <div className="inputs">
                  <div className="flex-box">
                    <div className="leading-icon">
                      <i className="fa-solid fa-user fa-beat"></i>
                    </div>
                    <label htmlFor="agentid" className="label">
                      Agent ID
                    </label>
                  </div>
                  {/* ----------------------------------------------- */}
                  <input
                    id="agentid"
                    name="agentid"
                    type="text"
                    placeholder="Select Your Agent ID"
                    value={values.agentid}
                    onChange={(e) => {
                      setAgentId(e.target.value);
                      handleChange(e);
                    }}
                    onBlur={handleBlur}
                    className="input"
                    list="agentIdSuggestions"
                    autoComplete="off"
                  />
                  <datalist id="agentIdSuggestions">
                    {agentIdSuggestions.map((agentid, index) => (
                      <option key={index} value={agentid} />
                    ))}
                  </datalist>
                  {errors.agentid && touched.agentid && (
                    <div className="input-feedback">{errors.agentid}</div>
                  )}
                </div>

                {/* ************* Button *********************** */}
                <div className="button-div">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="glow-on-hover"
                  >
                    LOGIN
                  </button>
                </div>
                <br></br>
              </form>
            </fieldset>
          </div>
        );
      }}
    </Formik>
  );
};
export default Login;
