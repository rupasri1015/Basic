import React from "react";

const Premium = () => {
  return (
    <form>
      <div>
        <div className="row">
            <label htmlFor="vehicleId">Vehicle Id:</label>
        </div>
      </div>
    </form>
  );
};

export default Premium;
