import React, { createContext, useState } from 'react';

export const DataContext = createContext();

export const DataProvider = ({ children }) => {
  const [mandatoryData, setMandatoryData] = useState(null);
  const [liabilityData, setLiabilityData] = useState(null);
  const [physicalDamageData, setPhysicalDamageData] = useState(null);

  return (
    <DataContext.Provider value={{ 
      mandatoryData, setMandatoryData, 
      liabilityData, setLiabilityData, 
      physicalDamageData, setPhysicalDamageData 
    }}>
      {children}
    </DataContext.Provider>
  );
};
