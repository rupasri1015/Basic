import React, { useState, useContext, useEffect } from "react";
import SideNav from "./SideNav";
import { useNavigate } from "react-router-dom";
import { DataContext } from "../DataContext";
import "./Coverages.css";

function PhysicalDamage() {
  const { physicalDamageData, setPhysicalDamageData } = useContext(DataContext);

  const navigate = useNavigate();

  const [comprehensive, setComprehensive] = useState("");
  const [collision, setCollision] = useState("");
  const [medicalPayments, setMedicalPayments] = useState("");
  const [towingAndLabor, setTowingAndLabor] = useState("");
  const [rentalReimbursement, setRentalReimbursement] = useState("");

  const [comprehensiveError, setComprehensiveError] = useState("");
  const [collisionError, setCollisionError] = useState("");
  const [medicalPaymentsError, setMedicalPaymentsError] = useState("");
  const [towingAndLaborError, setTowingAndLaborError] = useState("");
  const [rentalReimbursementError, setRentalReimbursementError] = useState("");

  useEffect(() => {
    if (physicalDamageData) {
      setComprehensive(physicalDamageData.comprehensive || "");
      setCollision(physicalDamageData.collision || "");
      setMedicalPayments(physicalDamageData.medicalPayments || "");
      setTowingAndLabor(physicalDamageData.towingAndLabor || "");
      setRentalReimbursement(physicalDamageData.rentalReimbursement || "");
    }
  }, [physicalDamageData]);

  const validateInput = (name, value) => {
    if (name === "comprehensive" && parseInt(value) > 10000) {
      return "Comprehensive value cannot exceed 10000$";
    }
    if (name === "collision" && parseInt(value) > 10000) {
      return "Collision value cannot exceed 10000$";
    }
    if (name === "medicalPayments" && parseInt(value) > 10000) {
      return "Medical Payments value cannot exceed 10000$";
    }
    if (name === "towingAndLabor" && parseInt(value) > 10000) {
      return "Towing and Labor value cannot exceed 10000$";
    }
    if (name === "rentalReimbursement" && parseInt(value) > 10000) {
      return "Rental Reimbursement value cannot exceed 10000$";
    }
    return "";
  };

  const handleChange = (e, name) => {
    const value = e.target.value;

    if (name === "comprehensive") {
      setComprehensive(value);
      setComprehensiveError(validateInput(name, value));
    } else if (name === "collision") {
      setCollision(value);
      setCollisionError(validateInput(name, value));
    } else if (name === "medicalPayments") {
      setMedicalPayments(value);
      setMedicalPaymentsError(validateInput(name, value));
    } else if (name === "towingAndLabor") {
      setTowingAndLabor(value);
      setTowingAndLaborError(validateInput(name, value));
    } else if (name === "rentalReimbursement") {
      setRentalReimbursement(value);
      setRentalReimbursementError(validateInput(name, value));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const comprehensiveError = validateInput("comprehensive", comprehensive);
    const collisionError = validateInput("collision", collision);
    const medicalPaymentsError = validateInput(
      "medicalPayments",
      medicalPayments
    );
    const towingAndLaborError = validateInput("towingAndLabor", towingAndLabor);
    const rentalReimbursementError = validateInput(
      "rentalReimbursement",
      rentalReimbursement
    );

    setComprehensiveError(comprehensiveError);
    setCollisionError(collisionError);
    setMedicalPaymentsError(medicalPaymentsError);
    setTowingAndLaborError(towingAndLaborError);
    setRentalReimbursementError(rentalReimbursementError);

    if (
      comprehensiveError ||
      collisionError ||
      medicalPaymentsError ||
      towingAndLaborError ||
      rentalReimbursementError
    ) {
      return;
    }

    const data = {
      comprehensive,
      collision,
      medicalPayments,
      towingAndLabor,
      rentalReimbursement,
    };

    console.log(data);
    setPhysicalDamageData(data);
    navigate("/afterLogin/coverageSelection");
  };

  return (
    <div>
      <div>
        <SideNav />
      </div>
      <div>
        <h2>Physical Damage Coverage</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group row">
            <label htmlFor="comprehensive" className="col-sm-4 col-form-label">
              Comprehensive Deductible:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="comprehensive"
                  name="comprehensive"
                  value={comprehensive}
                  onChange={(e) => handleChange(e, "comprehensive")}
                />
              </div>
            </div>
            {comprehensiveError && (
              <p className="errors">{comprehensiveError}</p>
            )}
          </div>
          <div className="form-group row">
            <label htmlFor="collision" className="col-sm-4 col-form-label">
              Collision Deductible:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="collision"
                  name="collision"
                  value={collision}
                  onChange={(e) => handleChange(e, "collision")}
                />
              </div>
            </div>
            {collisionError && <p className="errors">{collisionError}</p>}
          </div>
          <div className="form-group row">
            <label
              htmlFor="medicalPayments"
              className="col-sm-4 col-form-label"
            >
              Medical Payments Coverage (MedPay) Limit:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="medicalPayments"
                  name="medicalPayments"
                  value={medicalPayments}
                  onChange={(e) => handleChange(e, "medicalPayments")}
                />
              </div>
            </div>
            {medicalPaymentsError && (
              <p className="errors">{medicalPaymentsError}</p>
            )}
          </div>
          <div className="form-group row">
            <label htmlFor="towingAndLabor" className="col-sm-4 col-form-label">
              Towing and Labor Coverage Limit:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="towingAndLabor"
                  name="towingAndLabor"
                  value={towingAndLabor}
                  onChange={(e) => handleChange(e, "towingAndLabor")}
                />
              </div>
            </div>
            {towingAndLaborError && (
              <p className="errors">{towingAndLaborError}</p>
            )}
          </div>
          <div className="form-group row">
            <label
              htmlFor="rentalReimbursement"
              className="col-sm-4 col-form-label"
            >
              Rental Reimbursement Coverage Limit:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="rentalReimbursement"
                  name="rentalReimbursement"
                  value={rentalReimbursement}
                  onChange={(e) => handleChange(e, "rentalReimbursement")}
                />
              </div>
            </div>
            {rentalReimbursementError && (
              <p className="errors">{rentalReimbursementError}</p>
            )}
          </div>
          <button type="submit" className="btn btn-primary physical-btn">
            Save & Next
          </button>
        </form>
      </div>
    </div>
  );
}

export default PhysicalDamage;
