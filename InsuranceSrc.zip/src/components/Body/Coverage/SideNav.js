import React from 'react';
import "./Coverages.css";
import { NavLink } from 'react-router-dom';

function SideNav() {
  const handle = () => {
    document.querySelector("#liability").classList.remove("disabled")
  }
  return (
    <div>
        <div className='div-nav'>
        <div className='Form-nav'>
            <div className='slide-bar'>
            <NavLink 
                to='/afterLogin/mandatory' id='mandatory' onClick={handle}  className='Form-nav-link'
              >
                Mandatory Coverage
            </NavLink>
            </div>
            <div className='slide-bar'>
            <NavLink 
                to='/afterLogin/liability' id='liability'  className='Form-nav-link disabled'
              >
                Liability Coverage
          </NavLink>
            </div>
            <div className='slide-bar'>
            <NavLink 
              to='/afterLogin/physicalDamage' className='Form-nav-link'
            >
              Physical Damage Coverage
          </NavLink>
            </div>
        </div>
        </div>
        
    </div>
  )
}

export default SideNav