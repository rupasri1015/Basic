import React, { useState, useContext, useEffect } from "react";
import SideNav from "./SideNav";
import { useNavigate } from "react-router-dom";
import { DataContext } from "../DataContext";
import "./Coverages.css";

function LiabilityCoverage() {
  const { liabilityData, setLiabilityData } = useContext(DataContext);

  const navigate = useNavigate();

  const [bilperPerson, setBilperPerson] = useState("");
  const [bilperAccident, setBilperAccident] = useState("");
  const [uimperPerson, setUimperPerson] = useState("");
  const [uimperAccident, setUimperAccident] = useState("");

  useEffect(() => {
    if (liabilityData) {
      setBilperPerson(liabilityData.bilperPerson || "");
      setBilperAccident(liabilityData.bilperAccident || "");
      setUimperPerson(liabilityData.uimperPerson || "");
      setUimperAccident(liabilityData.uimperAccident || "");
    }
  }, [liabilityData]);

  const [errors, setErrors] = useState({
    bilperPerson: "",
    bilperAccident: "",
    uimperPerson: "",
    uimperAccident: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "bilperPerson") {
      setBilperPerson(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        bilperPerson: validateInput(value),
      }));
    } else if (name === "bilperAccident") {
      setBilperAccident(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        bilperAccident: validateInput(value),
      }));
    } else if (name === "uimperPerson") {
      setUimperPerson(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        uimperPerson: validateInput(value),
      }));
    } else if (name === "uimperAccident") {
      setUimperAccident(value);
      setErrors((previousErrors) => ({
        ...previousErrors,
        uimperAccident: validateInput(value),
      }));
    }
  };

  const validateInput = (value) => {
    if (parseInt(value) > 10000) {
      return "Value can not exceed 10000$";
    }
    return "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const bilperPersonError = validateInput(bilperPerson);
    const bilperAccidentError = validateInput(bilperAccident);
    const uimperPersonError = validateInput(uimperPerson);
    const uimperAccidentError = validateInput(uimperAccident);

    setErrors({
      bilperPerson: bilperPersonError,
      bilperAccident: bilperAccidentError,
      uimperPerson: uimperPersonError,
      uimperAccident: uimperAccidentError,
    });

    if (
      bilperPersonError ||
      bilperAccidentError ||
      uimperPersonError ||
      uimperAccidentError
    ) {
      return;
    }

    const data = {
      bilperPerson,
      bilperAccident,
      uimperPerson,
      uimperAccident,
    };

    console.log(data);
    navigate("/afterLogin/physicalDamage");
    setLiabilityData(data);
  };

  return (
    <div>
      <div>
        <SideNav />
      </div>
      <div>
        <h2>Liability Coverage</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group row">
            <label htmlFor="bilperPerson" className="col-sm-6 col-form-label">
              Bodily Injury Liability (BIL) Coverage Limit per person:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="bilperPerson"
                  name="bilperPerson"
                  value={bilperPerson}
                  onChange={handleChange}
                />
              </div>
            </div>
            {errors.bilperPerson && (
              <p className="errors">{errors.bilperPerson}</p>
            )}
          </div>

          <div className="form-group row">
            <label htmlFor="bilperAccident" className="col-sm-6 col-form-label">
              Bodily Injury Liability (BIL) Coverage Limit per accident:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="bilperAccident"
                  name="bilperAccident"
                  value={bilperAccident}
                  onChange={handleChange}
                />
              </div>
            </div>
            {errors.bilperAccident && (
              <p className="errors">{errors.bilperAccident}</p>
            )}
          </div>

          <div className="form-group row">
            <label htmlFor="uimperPerson" className="col-sm-6 col-form-label">
              Uninsured/Underinsured Motorist (UM/UIM) Coverage Limit per
              person:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="uimperPerson"
                  name="uimperPerson"
                  value={uimperPerson}
                  onChange={handleChange}
                />
              </div>
            </div>
            {errors.uimperPerson && (
              <p className="errors">{errors.uimperPerson}</p>
            )}
          </div>

          <div className="form-group row">
            <label htmlFor="uimperAccident" className="col-sm-6 col-form-label">
              Uninsured/Underinsured Motorist (UM/UIM) Coverage Limit per
              accident:
            </label>
            <div className="col-sm-4">
              <div className="input-icon">
                <i className="fas fa-dollar-sign"></i>
                <input
                  type="number"
                  id="uimperAccident"
                  name="uimperAccident"
                  value={uimperAccident}
                  onChange={handleChange}
                />
              </div>
            </div>
            {errors.uimperAccident && (
              <p className="errors">{errors.uimperAccident}</p>
            )}
          </div>
          <button type="submit" className="btn btn-primary liability-btn">
            Save & Next
          </button>
        </form>
      </div>
    </div>
  );
}

export default LiabilityCoverage;
