import React, { useState, useContext, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { DataContext } from "../DataContext";
import Axios from "axios";
import "./Coverages.css";

const CoverageSelection = () => {

  const { mandatoryData, setMandatoryData, liabilityData, setLiabilityData, physicalDamageData, setPhysicalDamageData }
   = useContext(DataContext);

  const [isMandatoryChecked, setIsMandatoryChecked] = useState(true);
  const [isLiabilityChecked, setIsLiabilityChecked] = useState(false);
  const [isPhysicalDamageChecked, setIsPhysicalDamageChecked] = useState(false);

  const [personalProtection, setPersonalProtection] = useState(500);
  const [propertyDamage, setPropertyDamage] = useState(500);
  const [bilperPerson, setBilperPerson] = useState("");
  const [bilperAccident, setBilperAccident] = useState("");
  const [uimperPerson, setUimperPerson] = useState("");
  const [uimperAccident, setUimperAccident] = useState("");
  const [comprehensive, setComprehensive] = useState("");
  const [collision, setCollision] = useState("");
  const [medicalPayments, setMedicalPayments] = useState("");
  const [towingAndLabor, setTowingAndLabor] = useState("");
  const [rentalReimbursement, setRentalReimbursement] = useState("");

  useEffect(() => {
    if (mandatoryData || liabilityData || physicalDamageData) {
      setPersonalProtection(mandatoryData.personalProtection || "");
      setPropertyDamage(mandatoryData.propertyDamage || "");
      setBilperPerson(liabilityData.bilperPerson || "");
      setBilperAccident(liabilityData.bilperAccident || "");
      setUimperPerson(liabilityData.uimperPerson || "");
      setUimperAccident(liabilityData.uimperAccident || "");
      setComprehensive(physicalDamageData.comprehensive || "");
      setCollision(physicalDamageData.collision || "");
      setMedicalPayments(physicalDamageData.medicalPayments || "");
      setTowingAndLabor(physicalDamageData.towingAndLabor || "");
      setRentalReimbursement(physicalDamageData.rentalReimbursement || "");
    }
  }, [mandatoryData, liabilityData, physicalDamageData]);

  const handleMandatoryCheckboxChange = () => {
    setIsMandatoryChecked(!isMandatoryChecked);
  };
  const handleLiabilityCheckboxChange = () => {
    setIsLiabilityChecked(!isLiabilityChecked);
  };
  const handlePhysicalDamageCheckboxChange = () => {
    setIsPhysicalDamageChecked(!isPhysicalDamageChecked);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    let dataToSave = {};

  if (isMandatoryChecked) {
    dataToSave = { ...dataToSave, personalProtection, propertyDamage };
    setMandatoryData({ personalProtection, propertyDamage });
  }
  else {
    ////--------------default values for Mandatory section if not visited------------------//
    dataToSave = { ...dataToSave, personalProtection: 50, propertyDamage: 50 };
    setMandatoryData({ personalProtection: 50, propertyDamage: 50 });
  }


  if (isLiabilityChecked) {
    dataToSave = {
      ...dataToSave,
      bilperPerson,
      bilperAccident,
      uimperPerson,
      uimperAccident,
    };
    setLiabilityData({ 
      bilperPerson, 
      bilperAccident, 
      uimperPerson, 
      uimperAccident 
    });
  }
  else {
    ////-----------------default values for Liability section if not visited-----------------//
    dataToSave = {
      ...dataToSave,
      bilperPerson: "",
      bilperAccident: "",
      uimperPerson: "",
      uimperAccident: "",
    };
    setLiabilityData({ 
      bilperPerson: "", 
      bilperAccident: "", 
      uimperPerson: "", 
      uimperAccident: "" 
    });
  }

  if (isPhysicalDamageChecked) {
    dataToSave = {
      ...dataToSave,
      comprehensive,
      collision,
      medicalPayments,
      towingAndLabor,
      rentalReimbursement,
    };
    setPhysicalDamageData({
      comprehensive,
      collision,
      medicalPayments,
      towingAndLabor,
      rentalReimbursement
    });
  }
  else {
    ////---------------default values for Physical Damage section if not visited-------------//
    dataToSave = {
      ...dataToSave,
      comprehensive: "",
      collision: "",
      medicalPayments: "",
      towingAndLabor: "",
      rentalReimbursement: "",
    };
    setPhysicalDamageData({
      comprehensive: "",
      collision: "",
      medicalPayments: "",
      towingAndLabor: "",
      rentalReimbursement: "",
    });
  }

  saveDataToServer(dataToSave);
  };
  
  const saveDataToServer = (dataToSave) => {
    Axios.post("http://localhost:8083/addcoverages", dataToSave)
      .then((response) => {
        console.log(response);
        alert("Data saved successfully");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Error saving data to database:", error);
        alert("Error saving data to database");
      });
  };

  return (
        <form onSubmit={handleSubmit}>
          <div className="row">
            {/*-------------- Mandatory Coverage ------------- */}
            <div className="col-md-4">
              <NavLink to="/afterLogin/mandatory" className="coverage-link">Mandatory Coverage</NavLink>
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  name="mandatory"
                  id="mandatory"
                  checked={isMandatoryChecked}
                  onChange={handleMandatoryCheckboxChange}
                  disabled
                />
                <label className="form-check-label" htmlFor="mandatory">
                  Mandatory Coverage
                </label>
              </div>
            </div>

            {/* ------------- Liability Coverage -------------  */}
            <div className="col-md-4">
              <NavLink to="/afterLogin/liability" className="coverage-link">Liability Coverage</NavLink>
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  name="liability"
                  id="liability"
                  checked={isLiabilityChecked}
                  onChange={handleLiabilityCheckboxChange}
                />
                <label className="form-check-label" htmlFor="mandatory">
                  Liability Coverage
                </label>
              </div>
            </div>

            {/*------------- Physical Damage Coverage -------------- */}
            <div className="col-md-4">
              <NavLink to="/afterLogin/physicalDamage" className="coverage-link">Physical Damage Coverage</NavLink>
              <div className="form-check">
                <input
                  type="checkbox"
                  name="physicalDamage"
                  id="physicalDamage"
                  className="form-check-input"
                  checked={isPhysicalDamageChecked}
                  onChange={handlePhysicalDamageCheckboxChange}
                />{" "}
                <label className="form-check-label" htmlFor="mandatory">Physical Damage Coverage</label>
              </div>
            </div>
            {/* Disable conetent Mandatory Coverage */}
            <div className="coverage-data">
              <label htmlFor="personalProtection">
                Personal Injury Protection (PIP) Coverage Limit:
              </label>
              <input
                type="number"
                id="personalProtection"
                name="personalProtection"
                value={personalProtection}
                onChange={(e) => setPersonalProtection(e.target.value)}
                disabled
              />
              <label htmlFor="propertyDamage">
                Property Damage Liability (PDL) Coverage Limit:
              </label>
              <input
                type="number"
                id="propertyDamage"
                name="propertyDamage"
                value={propertyDamage}
                onChange={(e) => setPropertyDamage(e.target.value)}
                disabled
              />
            </div>
            <div className="coverage-data">
              <label htmlFor="bilperPerson">
                Bodily Injury Liability (BIL) Coverage Limit per person:
              </label>
              <input
                type="number"
                id="bilperPerson"
                name="bilperPerson"
                value={bilperPerson}
                onChange={(e) => setBilperPerson(e.target.value)}
                disabled
              />
              <label htmlFor="bilperAccident">
                Bodily Injury Liability (BIL) Coverage Limit per accident:
              </label>
              <input
                type="number"
                id="bilperAccident"
                name="bilperAccident"
                value={bilperAccident}
                onChange={(e) => setBilperAccident(e.target.value)}
                disabled
              />
              <label htmlFor="uimperPerson">
                Uninsured/Underinsured Motorist (UM/UIM) Coverage Limit per
                person:
              </label>
              <input
                type="number"
                id="uimperPerson"
                name="uimperPerson"
                value={uimperPerson}
                onChange={(e) => setUimperPerson(e.target.value)}
                disabled
              />
              <label htmlFor="uimperAccident">
                Uninsured/Underinsured Motorist (UM/UIM) Coverage Limit per
                accident:
              </label>
              <input
                type="number"
                id="uimperAccident"
                name="uimperAccident"
                value={uimperAccident}
                onChange={(e) => setUimperAccident(e.target.value)}
                disabled
              />
            </div>
            <div className="coverage-data">
              <label htmlFor="comprehensive">Comprehensive Deductible:</label>
              <input
                type="number"
                id="comprehensive"
                name="comprehensive"
                value={comprehensive}
                onChange={(e) => setComprehensive(e.target.value)}
                disabled
              />
              <label htmlFor="collision">Collision Deductible:</label>
              <input
                type="number"
                id="collision"
                name="collision"
                value={collision}
                onChange={(e) => setCollision(e.target.value)}
                disabled
              />
              <label htmlFor="medicalPayments">
                Medical Payments Coverage (MedPay) Limit:
              </label>
              <input
                type="number"
                id="medicalPayments"
                name="medicalPayments"
                value={medicalPayments}
                onChange={(e) => setMedicalPayments(e.target.value)}
                disabled
              />
              <label htmlFor="towingAndLabor">
                Towing and Labor Coverage Limit:
              </label>
              <input
                type="number"
                id="towingAndLabor"
                name="towingAndLabor"
                value={towingAndLabor}
                onChange={(e) => setTowingAndLabor(e.target.value)}
                disabled
              />
              <label htmlFor="rentalReimbursement">
                Rental Reimbursement Coverage Limit:
              </label>
              <input
                type="number"
                id="rentalReimbursement"
                name="rentalReimbursement"
                value={rentalReimbursement}
                onChange={(e) => setRentalReimbursement(e.target.value)}
                disabled
              />
            </div>
            <div className="row mt-3">
              <div className="col-md-12 text-center">
                <button type="submit" className="btn btn-primary">
                  SUBMIT
                </button>
              </div>
            </div>
          </div>
        </form>
  );
};

export default CoverageSelection;
