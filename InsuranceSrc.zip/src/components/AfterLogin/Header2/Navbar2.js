import React from "react";
import { Navbar, Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom";

const Navbar2 = () => {
  

  return (
    <Navbar bg="light" expand="lg" sticky="top">
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto">
          <NavLink to="/afterLogin/vehicleDetails" className="nav-link">
            VEHICLE
          </NavLink>
          <NavLink to="/afterLogin/driver" className="nav-link">
            DRIVER
          </NavLink>
          <NavLink to="/afterLogin/coverageSelection" className="nav-link">
            COVERAGES
          </NavLink>
          <NavLink to="/afterLogin/premium" className="nav-link">
            PREMIUM
          </NavLink>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}

export default Navbar2;
