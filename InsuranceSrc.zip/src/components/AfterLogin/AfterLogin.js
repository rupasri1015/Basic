import Header2 from "./Header2/Header2";
import { Outlet } from "react-router-dom";

const AfterLogin = () => {
  return (
    <div>
        <Header2 />
      <Outlet />
      
    </div>
  )
}

export default AfterLogin;
